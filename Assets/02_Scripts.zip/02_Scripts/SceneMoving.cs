using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneMoving : MonoBehaviour {
    [SerializeField]
    private AudioSource musicPlayer;
    [SerializeField]
    private AudioClip sfx_menu;

    public void goto_MainGame() {
        UnityEngine.SceneManagement.SceneManager.LoadScene("maingame");
        musicPlayer.PlayOneShot(sfx_menu);
    }

    public void goto_Start() {
        UnityEngine.SceneManagement.SceneManager.LoadScene("start");
        musicPlayer.PlayOneShot(sfx_menu);
    }

    public void goto_Ready() {
        UnityEngine.SceneManagement.SceneManager.LoadScene("ready");
        musicPlayer.PlayOneShot(sfx_menu);
    }

    public void goto_Options() {
        UnityEngine.SceneManagement.SceneManager.LoadScene("options");
        musicPlayer.PlayOneShot(sfx_menu);
    }

    public void goto_Howtoplay() {
        UnityEngine.SceneManagement.SceneManager.LoadScene("howtoplay");
        musicPlayer.PlayOneShot(sfx_menu);
    }
}
