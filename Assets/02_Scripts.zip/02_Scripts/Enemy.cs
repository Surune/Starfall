﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using static GameState;

public class Enemy : MonoBehaviour {
    [SerializeField]
    private int type;
    [SerializeField]
    private SpriteRenderer sprite_renderer;
    private static Player player;
    private static ScoreManager scorer;
    private static ExpManager exp_manager;
    private static EffectManager eff_manager;
    private static PlayerManager plm;
    private static AbilityManager abilm;
    [SerializeField]
    private TextMeshProUGUI resourceText;
    [HideInInspector]
    public bool isBoss = false;
    private static float[] basehp_list = {0f, 1f, 1f, 1f, 1f, 1f, 1f};
    private static float[] stagehp_list = {1f, 0.75f, 0.1f, 1f, 1.4f, 1.5f, 1.6f};
    [HideInInspector]
    public float maxspeed = 10f;
    private float speed;
    [HideInInspector]
    public float slow_time = 0f;
    [HideInInspector]
    public float maxHP = 2f;
    public float currentHP = 2f;
    public static float dmg_coeff = 1f;    //damage coefficient
    [SerializeField]
    private Vector3 move_dir = new Vector3(0, -1, 0);
    [HideInInspector]
    public int exp_amount = 0;
    [HideInInspector]
    public bool makes_meteor = false;
    public static float item_prob = 3f;

    void Start () {
        if (player == null)         player = GameManager.Instance.player;
        if (scorer == null)         scorer = GameManager.Instance.scorer;
        if (eff_manager == null)    eff_manager = GameManager.Instance.eff;
        if (abilm == null)          abilm = GameManager.Instance.abilm;
        if (exp_manager == null)    exp_manager = GameManager.Instance.exp;
        if (plm == null)            plm = GameManager.Instance.plm;
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
        enabled = (GameStateManager.Instance.CurrentGameState == GameState.Gameplay);
        SetHPText();
    }
    
    public void SetHPText(){
        resourceText.text = "" + Mathf.CeilToInt(currentHP);
    }

    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    // type_num = 0 ~ 6
    public void SetType(int type_num) {
        type = type_num;
        maxHP = basehp_list[type] + stagehp_list[type] * (GameManager.Instance.timer.wavenum * GameManager.Instance.timer.wavenum + GameManager.Instance.timer.roundnum - 1);
        currentHP = maxHP;
        speed = maxspeed;
        SetHPText();
        if (type == 4) {
            Vector3 worldpos = Camera.main.WorldToViewportPoint(this.transform.position);
            if (worldpos.x < 0.5f)
                move_dir = new Vector3(0.5f, -1, 0);
            else
                move_dir = new Vector3(-0.5f, -1, 0);
        }
        else    
            move_dir = Vector3.down;
    }

    public void MakeBoss() {
        isBoss = true;
        maxHP += stagehp_list[type] * (GameManager.Instance.timer.wavenum * GameManager.Instance.timer.wavenum + 7);
        currentHP = maxHP;
        maxspeed *= 0.5f;
        speed = maxspeed;
        SetHPText();
        this.transform.localScale *= 2f;
    }

    public bool GetDamage(float dmg, bool critical = false, bool mute = false, bool fatal = false) {
        dmg *= dmg_coeff;
        if (abilm.culling && maxHP == currentHP) {
            dmg *= 1.25f;
        }
        dmg = dmg < 0f ? 0f : dmg;
        currentHP -= dmg;
        eff_manager.SetDamageEffect(transform.position, dmg, isCritical : critical, isFatal : fatal);
        if (critical) {
            if (abilm.fifth) {
                plm.critical_count++;
                if(plm.critical_count % 5 == 0) {
                    player.Echoshot(1);
                }
            }
            if (abilm.psychosense) {
                GameObject fireball = GameManager.Instance.pool.Get(1);
                fireball.transform.position = player.transform.position;
                fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                fireball.GetComponent<Fireball>().damage = 3f;
            }
        }
        
        GameObject p = GameManager.Instance.pool.Get(3);
        p.transform.position = transform.position;
        
        SetHPText();
        bool dead = CheckIfDead(fatal);
        if (!mute && !dead) {
            if (critical)   eff_manager.PlayEnemySound(isCritical : true);
            else    eff_manager.PlayEnemySound();
        }
        if (dead && abilm.noxious) {
            plm.DamageAllEnemy(plm.damage * plm.dmg_coeff + plm.fix_damage);
        }
        return dead;
    }

    public bool GetHeal(float heal_amount) {
        if (maxHP - currentHP > 0.0001f) {
            heal_amount = currentHP + heal_amount > maxHP ? maxHP - currentHP : heal_amount;
            currentHP += heal_amount;
            eff_manager.SetDamageEffect(transform.position, heal_amount, isCritical : false, isFatal : false, isHeal : true);
            SetHPText();
            return true;
        }
        else
            return false;
    }

    private bool CheckIfDead(bool fatal = false) {
        bool isDead = false;
        if (fatal == true && isBoss == false && gameObject.activeSelf) {
            if (abilm.kinetic_barrage)  player.Echoshot(2);
            isDead = true;
        }
        else if (currentHP <= 0f && gameObject.activeSelf) {
            if (type == 3) {
                List<Transform> enemies = GameManager.GetAllChilds(GameManager.Instance.enemylist);
                foreach(Transform e in enemies) {
                    if (e == this.transform) {
                        continue;
                    }
                    e.GetComponent<Enemy>().GetHeal(GameManager.Instance.timer.wavenum);
                }
            }
            else if (type == 6) {
                var fireballs = GameManager.GetAllChilds(GameManager.Instance.fireballlist);
                foreach(Transform f in fireballs){
                    f.gameObject.SetActive(false);
                }
            }
            isDead = true;
        }

        if (isDead) {
            GameManager.Instance.active_enemy_num -= 1;
            player.killnum += 1;

            if (type == 5 || makes_meteor) {
                GameManager.Instance.spawner.SpawnMeteor(type);
            }

            GameObject eff = GameManager.Instance.pool.Get(6);
            eff.transform.position = transform.position;
            eff.transform.localScale = transform.localScale;
            var p = eff.GetComponent<ParticleSystem>().main;
            p.startColor = transform.GetChild(0).GetComponent<SpriteRenderer>().color;

            eff.GetComponent<Exp>().exp_amount = exp_amount;
            if (fatal == true && abilm.firm)    eff.GetComponent<Exp>().exp_amount += 1;
            if (abilm.burning && type == 0)   eff.GetComponent<Exp>().exp_amount += 1;

            if (abilm.echo)     player.Echoshot(2);
            if (abilm.magnet)   player.Magnetism(this.transform);
            if (abilm.explode)  player.Explode(this.transform, 1f);

            eff_manager.PlayEnemySound(isKilled : true);
            scorer.GetScore(exp_amount);
            if((int)Random.Range(0, 100) < item_prob) {
                GameObject item = GameManager.Instance.pool.Get(7);
                item.transform.position = transform.position;
                item.GetComponent<DropItem>().SetType((int)Random.Range(0, 4));
            }
            gameObject.SetActive(false);
            
        }

        return isDead;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Area") {
            var collidedarea = collision.gameObject.GetComponent<Area>();
            if (collidedarea.slow) speed = maxspeed * 0.75f;
            if (collidedarea.damage) currentHP -= Time.deltaTime;
        }
        else if (collision.transform.tag == "Player") {
            GameManager.Instance.hp.GetDamage(-Mathf.CeilToInt(currentHP));
            GameManager.Instance.active_enemy_num -= 1;
            exp_manager.GetExp(exp_amount);
            scorer.GetScore(exp_amount);
            gameObject.SetActive(false);
        }
    }
    
    private void OnTriggerStay2D(Collider2D collision) {
        if (collision.transform.tag == "Area") {
            var collidedarea = collision.gameObject.GetComponent<Area>();
            if (collidedarea.slow) speed = maxspeed * 0.75f;
            if (collidedarea.damage) currentHP -= Time.deltaTime;
        }
    }

    private void OnTriggerExit2D(Collider2D collision) {
        if (collision.transform.tag == "Area")
            speed = maxspeed;
    }

    private void CheckInvisible() {
        Vector3 worldpos = Camera.main.WorldToViewportPoint(transform.position);
        if (worldpos.y < 0f) {
            gameObject.SetActive(false);
            GameManager.Instance.active_enemy_num -= 1;
            GameManager.Instance.spawner.SpawnMeteor(type);
        }
        else if (worldpos.x < 0f)
            move_dir = new Vector3(0.5f, -1, 0);
        else if (worldpos.x > 1f)
            move_dir = new Vector3(-0.5f, -1, 0);
    }

    void Update () {
        if (enabled) {
            if (slow_time > 0f) {
                slow_time -= Time.deltaTime;
                speed = maxspeed * 0.75f;
                if (slow_time <= 0f) {
                    slow_time = 0f;
                    speed = maxspeed;
                }
            }
            transform.Translate(move_dir * speed * Time.deltaTime);
            CheckInvisible();
        }
    }

    private void OnGameStateChanged(GameState newGameState) {
        enabled = (newGameState == GameState.Gameplay);
    }
}
