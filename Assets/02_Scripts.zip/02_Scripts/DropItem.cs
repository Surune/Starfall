using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropItem : MonoBehaviour {
    [HideInInspector]
    public static HPManager hp;
    [HideInInspector]
    public static PlayerManager plm;
    private static EffectManager eff_manager;
    public SpriteRenderer spr;
    public Sprite[] itemSprites;
    public int type = 0;

    private void Start() {
        if (hp == null) 
            hp = GameManager.Instance.hp;
        if (plm == null)
            plm = GameManager.Instance.plm;
        if (eff_manager == null)
            eff_manager = GameObject.Find("Effects").GetComponent<EffectManager>();
    }
    
    public void SetType(int n) {
        type = n;
        spr.sprite = itemSprites[n];
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.transform.tag == "Player") {
            switch (type) {
                case 0: //wing
                    plm.GetWing(1);
                    break;
                case 1: //barrier
                    hp.GetBarrier(1);
                    break;
                case 2: //hp
                    hp.ChangeHP(10);
                    break;
                case 3: //damage
                    plm.DamageAllEnemy(plm.damage * plm.dmg_coeff + plm.fix_damage);
                    break;
            }
            if(plm.repair)      hp.ChangeHP(10);
            if(plm.jera)        plm.damage += 0.2f;
            if(plm.dagaz)       hp.GetBarrier(1);
            if(plm.reinforce)   plm.crit_prob += 0.1f;
            eff_manager.PlayItemSound();
            gameObject.SetActive(false);
        }
    }
}
