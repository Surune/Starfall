public enum GameState {
    Gameplay,
    Paused
}