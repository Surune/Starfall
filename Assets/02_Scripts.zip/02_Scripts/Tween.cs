using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Tween : MonoBehaviour {
    [SerializeField]
    public GameObject obj;
    [SerializeField]
    private float tweentime;
    
    public void tween() {
        Vector3 initPos = new Vector3(0f, 0f, 0f);
        transform.rotation = Quaternion.Euler(-450f, 0f, 0f);
        Time.timeScale = 1;
        transform.DORotate(new Vector3(0f, 0f, 0f), tweentime).SetEase(Ease.Linear);
    }
}
