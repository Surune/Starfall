using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoolManager : MonoBehaviour {
    // Variable to store prefabs
    public GameObject[] prefabs;

    // Variable to store prefabs
    public Transform[] contents;

    // List to work as pool
    List<GameObject>[] pools;

    int maxItem = 100;

    void Awake() {
        pools = new List<GameObject>[prefabs.Length];

        for (int idx = 0; idx < pools.Length; idx++) {
            pools[idx] = new List<GameObject>();
        }
    }

    public GameObject Get(int index) {
        GameObject select = null;

        // 선택한 풀의 놀고있는 게임오브젝트 접근
        foreach (GameObject item in pools[index]) {
            if(!item.activeSelf) {
                // 발견하면 select 변수에 접근
                select = item;
                select.SetActive(true);
                break;
            }
        }
        // 못 찾았으면
        if(!select) {
            if (index == 1 || pools[index].Count < maxItem){
                // 새롭게 생성하여 select에 할당
                select = Instantiate(prefabs[index], contents[index]);
                pools[index].Add(select);
            }
            else {
                select = pools[index][0];
                pools[index].RemoveAt(0);
                pools[index].Add(select);
            }
        }

        return select;
    }
}
