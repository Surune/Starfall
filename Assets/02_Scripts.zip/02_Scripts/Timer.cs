using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class Timer : MonoBehaviour {
    [SerializeField]
    private float time_max;
    private float time_remaining;
    public TextMeshProUGUI text;
    public int wavenum;
    public int roundnum;
    public int bossperwave = 7;
    public bool waiting = false;
    public float waittime_max = 0f;
    private float waittime_now = 0f;
    public int addition = 0;
    [SerializeField]
    private Spawner spawner;
    [SerializeField]
    private GameObject EnemyList;
    [SerializeField]
    private Color[] colors;
    [SerializeField]
    private Image fillarea;
    private AudioSource musicPlayer;
    [SerializeField]
    private AudioClip sfx_wave;
    [SerializeField]
    private AudioClip sfx_boss;
    [SerializeField]
    private AudioClip sfx_final_boss;

    // Use this for initialization
    void Start() {
        time_remaining = time_max;
        wavenum = 1;
        roundnum = 0;
        addition = 0;
        musicPlayer = GameObject.Find("Effects").GetComponent<AudioSource>();
        NextWave();
    }

    void NextWave() {
        roundnum++;
        if(roundnum >= bossperwave + 1) {
            roundnum -= bossperwave;
            wavenum += 1;
        }

        if(wavenum == 8) {
            if (roundnum == 1) {
                spawner.SpawnFinalBoss();
                SetText("SOMETHING BIG IS COMING...!", colors[2]);
                musicPlayer.PlayOneShot(sfx_final_boss);
                roundnum = 2;
            }
        }
        else {
            waiting = false;
            if (roundnum % bossperwave != 0) {  
                // Normal
                SetText("Wave " + wavenum + "-" + roundnum, colors[0]);
                time_remaining = time_max;
                spawner.enemynum = wavenum * (wavenum - 1) + roundnum + addition;
                musicPlayer.PlayOneShot(sfx_wave);
            }
            else {    
                // Boss
                SetText("Wave " + wavenum + "-Boss", colors[1]);
                time_remaining = time_max + wavenum;
                spawner.enemynum = wavenum * wavenum + 1;
                musicPlayer.PlayOneShot(sfx_boss);
            }
        }
    }

    void SetText(string t, Color c) {
        text.text = t;
        text.color = c;
    }

    // Update is called once per frame
    void Update() {
        if(GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            if (waiting) {
                waittime_now -= Time.deltaTime;
                if (waittime_now <= 0 && wavenum != 8) {
                    NextWave();
                }
            }
            else {
                if (time_remaining <= 0) {
                    waiting = true;
                    SetText("Wait...", colors[2]);
                    waittime_now = waittime_max;
                }
                else if(spawner.enemynum == 0 && GameManager.Instance.active_enemy_num == 0) { 
                    // if time is left and all enemy killed
                    waiting = true;
                    SetText("Wait...", colors[2]);
                    waittime_now = 0.25f;
                }
                else if(spawner.enemynum == 0) {
                    time_remaining -= Time.deltaTime;
                }
            }
        }
    }
}
