using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoInactivator : MonoBehaviour {
    [SerializeField]
    private float cooltime;

    void Start() {
        Invoke("destroythis", cooltime);
    }

    private void OnEnable() {
        Invoke("destroythis", cooltime);
    }

    void destroythis() {
        gameObject.SetActive(false);
    }
}
