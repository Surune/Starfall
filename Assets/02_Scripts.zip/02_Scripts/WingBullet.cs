using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static GameState;

public class WingBullet : MonoBehaviour {
    private static Player _player;
    private Vector3 worldpos;
    public static float speed = 20f;
    public static float damage = 1f;
    
    public static bool udo = false;
    public static bool freezing = false;

    private bool game_playing = true;

    void Start() {
        if(_player == null) _player = GameObject.Find("Player").GetComponent<Player>();
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
        speed = 20f;
        damage = 1f;
        udo = false;
        freezing = false;
    }

    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Enemy") {
            collision.gameObject.GetComponent<Enemy>().GetDamage(damage, critical : false, mute : true);
            if (freezing) collision.gameObject.GetComponent<Enemy>().slow_time = 2f;
            gameObject.SetActive(false);
        }
        else if (collision.transform.tag == "Boss") {
            collision.gameObject.GetComponent<Boss>().GetDamage(damage, critical : false);
            if (freezing) collision.gameObject.GetComponent<Boss>().slow_time = 2f;
            gameObject.SetActive(false);
        }
    }

    void FixedUpdate () {
        worldpos = Camera.main.WorldToViewportPoint(this.transform.position);
        if (worldpos.x < 0f || worldpos.x > 1f || worldpos.y < 0f || worldpos.y > 1f) {
            gameObject.SetActive(false);
        }
        else if(game_playing) {
            if (udo) {
                Transform closest = GameManager.FindClosestTransform(GameManager.GetAllChilds(GameManager.Instance.enemylist), this.transform.position);
                if (closest != null && Vector2.Distance(this.transform.position, closest.position) < 1f)
                        transform.position = Vector3.Lerp(this.transform.position, closest.position, Time.smoothDeltaTime * speed);
                else 
                    transform.Translate(0, Time.smoothDeltaTime * speed, 0);
            }
            else transform.Translate(0, Time.smoothDeltaTime * speed, 0);
        }
    }

    private void OnGameStateChanged(GameState newGameState) {
        game_playing = (newGameState == GameState.Gameplay);
    }
}
