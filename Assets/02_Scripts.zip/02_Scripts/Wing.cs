using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wing : MonoBehaviour {
    public static float skillcool_max = 1f;
    public static float crit_prob = 0f;
    private float mindelay = 0.0005f;

    public static bool freezing = false;

    private void Start() {
        InvokeRepeating("Shoot", 0f, skillcool_max);
    }

    public void ChangeSkillCool(float newcooltime) {
        if (newcooltime <= mindelay) newcooltime = mindelay;
        skillcool_max = newcooltime;
        CancelInvoke("Shoot");
        InvokeRepeating("Shoot", 0f, skillcool_max);
    }

    public void Shoot() {
        if (GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            GameObject fireball = GameManager.Instance.pool.Get(2);
            fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
            fireball.transform.position = this.transform.position;
        }
    }
}
