using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EffectManager : MonoBehaviour {
    private AudioSource musicplayer;
    [SerializeField]
    private AudioClip sfx_enemy_hit;
    [SerializeField]
    private AudioClip sfx_enemy_critical;
    [SerializeField]
    private AudioClip sfx_enemy_killed;
    [SerializeField]
    private AudioClip sfx_area_start;
    [SerializeField]
    private AudioClip sfx_area_end;
    [SerializeField]
    private AudioClip sfx_item;

    void Start () {
        musicplayer = gameObject.GetComponent<AudioSource>();
    }

    public void SetEffectText(DamageEffect e, string text, Color color) {
        e.acc_time = 0f;
        e.resourceText.text = text;
        e.resourceText.color = color;
    }

    public void SetDamageEffect(Vector3 pos, float dmg, bool isCritical = false, bool isFatal = false, bool isHeal = false) {
        var myVector = new Vector3(UnityEngine.Random.Range(-0.5f, 0.5f), UnityEngine.Random.Range(-0.5f, 0.5f), 0);
        GameObject effect = GameManager.Instance.pool.Get(3);
        effect.transform.position = pos + myVector;
        dmg = Mathf.Round(dmg * 100) * 0.01f;
        effect.transform.GetComponent<DamageEffect>().delay = 0.25f;
        if(isHeal) {
            SetEffectText(effect.transform.GetComponent<DamageEffect>(), "+" + dmg, Color.green);
        }
        else if(isFatal) {
            SetEffectText(effect.transform.GetComponent<DamageEffect>(), "X_X", Color.red);
        }
        else if(isCritical) {
            SetEffectText(effect.transform.GetComponent<DamageEffect>(), "-" + dmg + "!", Color.yellow);
        }
        else {
            SetEffectText(effect.transform.GetComponent<DamageEffect>(), "-" + dmg, Color.white);
        }
    }

    public void PlayEnemySound(bool isCritical = false, bool isKilled = false) {
        if (isKilled)           musicplayer.PlayOneShot(sfx_enemy_killed);
        else if (isCritical)    musicplayer.PlayOneShot(sfx_enemy_critical);
        else                    musicplayer.PlayOneShot(sfx_enemy_hit);
    }

    public void PlayAreaSound(bool start) {
        if (start)  musicplayer.PlayOneShot(sfx_area_start);
        else        musicplayer.PlayOneShot(sfx_area_end);
    }

    public void PlayItemSound() {
        musicplayer.PlayOneShot(sfx_item);
    }
}