using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class Exp : MonoBehaviour {
    private static Transform player;
    private static ExpManager expmanager;
    private static int speed = 10;
    private ParticleSystem p_System;
    private ParticleSystem.Particle[] particles;
    public int exp_amount = 0;

    void Start() {
        if (player == null) 
            player = GameObject.Find("Player").transform;
        if (expmanager == null)
            expmanager = GameObject.Find("ExpManager").GetComponent<ExpManager>();
        p_System = GetComponent<ParticleSystem>();
        particles = new ParticleSystem.Particle[p_System.main.maxParticles];
    }

    void Update() {
        if(GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            int particleCount = p_System.GetParticles(particles);

            for (int i = 0; i < particleCount; i++) {
                particles[i].position = Vector3.Lerp(particles[i].position, player.position, Time.smoothDeltaTime * speed);
            }
            this.transform.position = Vector3.Lerp(transform.position, player.position, Time.smoothDeltaTime * speed);

            p_System.SetParticles(particles, particleCount);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Player") {
            expmanager.GetExp(exp_amount);
            gameObject.SetActive(false);
        }
    }
}