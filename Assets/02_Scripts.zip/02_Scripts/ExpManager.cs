using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ExpManager : MonoBehaviour {
    [SerializeField]
    private TextMeshProUGUI resourceText;
    public float exp_cur = 0;
    public int exp_max = 10;
    [SerializeField]
    private AudioSource musicPlayer;
    [SerializeField]
    private AudioClip sfx_bonus;
    [SerializeField]
    private AudioClip sfx_exp;
    [SerializeField]
    private GameObject choice_prefab;
    public int coins;
    [HideInInspector]
    public bool hextech = false;

    private void Start() {
        coins = 0;
        exp_cur = 0;
        exp_max = 10;
        exp_cur += PlayerPrefs.GetInt("module_5");
        //SetText();
    }

    public void SetText() {
        resourceText.text = (int)exp_cur + "/" + exp_max;
    }

    public void GetExp(int num) {
        exp_cur += num;

        if (exp_cur >= exp_max) {
            if (hextech) GameManager.Instance.plm.refresh += 1;
            LevelUp();
        }
        else {
            musicPlayer.PlayOneShot(sfx_exp);
        }
        SetText();
    }

    public void LevelUp() {
        GameStateManager.Instance.SetState(GameState.Paused);
        exp_cur -= exp_max;
        exp_max += 5;
        Instantiate(choice_prefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        musicPlayer.PlayOneShot(sfx_bonus);
        coins += 5;
        SetText();
    }
}