using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour {
    public SpriteRenderer spr;
    public int refresh = 0;
    public float fix_damage = 0f;
    public float damage = 1f;
    public float dmg_coeff = 1f;
    public float crit_prob = 0f;
    public float crit_dmg = 1.5f;
    public float fatal_prob = 0f;
    public float shot_speed_coeff = 1f;
    private int shotnum = 0;
    public int critical_count = 0;
    private Transform EnemyList;
    public GameObject wing_prefab;
    public Transform wing_transform;
    public List<Wing> wings;
    private Player player;
    private HPManager hp;
    public AbilityManager abilm;
    private Spawner spawner;
    private Timer timer;
    private EffectManager eff_manager;
    private ExpManager exp_manager;
    public bool statikk = false;
    public bool aquaris = false;
    public bool repair = false;
    public bool jera = false;
    public bool dagaz = false;
    public bool reinforce = false;

    void Start() {
        EnemyList = GameObject.Find("Enemies").transform;
        timer = GameObject.Find("Timer").GetComponent<Timer>();
        exp_manager = GameManager.Instance.exp;
        spawner = GameObject.Find("Spawner").GetComponent<Spawner>();
        player = GameObject.Find("Player").GetComponent<Player>();
        hp = GameObject.Find("HPSlider").GetComponent<HPManager>();
        eff_manager = GameManager.Instance.eff;

        SetPlayer();
    }

    private void SetPlayer() {
        int currentPlayer = PlayerPrefs.GetInt("currentPilot", 1);
        switch(currentPlayer) {
            case 1:
                spr.color = Color.white;
                exp_manager.coins = -5;
                exp_manager.exp_cur = exp_manager.exp_max;
                exp_manager.LevelUp();
                break;
            case 2:
                spr.color = spawner.color_list[0];
                crit_prob += 0.2f;
                break;
            case 3:
                spr.color = spawner.color_list[2];
                player.ChangeSkillCool(player.skillcool_max * 0.8f);
                break;
            case 4:
                spr.color = spawner.color_list[3];
                hp.GetBarrier(5);
                break;
            case 5:
                spr.color = spawner.color_list[4];
                damage += 1f;
                break;
            case 6:
                spr.color = spawner.color_list[6];
                GameManager.Instance.coin_coeff += 0.5f;
                break;
        }
        if (currentPlayer != 1)
            GameStateManager.Instance.SetState(GameState.Gameplay);
        exp_manager.SetText();
    }
    
    public void DamageAllEnemy(float dmg) {
        eff_manager.PlayEnemySound(isCritical : false, isKilled : false);
        foreach (Transform t in GameManager.GetAllChilds(EnemyList)) {
            if (t.gameObject.tag == "Enemy") {
                t.gameObject.GetComponent<Enemy>().GetDamage(dmg, critical : false, mute : true);
            }
        }
    }

    public void MakeCritical(Fireball fireball) {
        fireball.isCritical = true;
        fireball.damage *= crit_dmg;
        fireball.burst = abilm.burst;
        if (abilm.nuker && crit_prob >= 1f) fireball.damage *= crit_prob;
        if (abilm.assassination)    fireball.penetrate = true;
    }

    public void SetFireInfo(Fireball fireball) {
        shotnum++;
        if (statikk && shotnum % 50 == 0) 
            DamageAllEnemy(damage * dmg_coeff + fix_damage);
        if (aquaris) fireball.isCritical = true;
        float rand = Random.value;
        if (rand <= fatal_prob) fireball.isFatal = true;
        else fireball.isFatal = false;
        
        fireball.damage = damage;
        if (rand <= crit_prob || (abilm.lucky_seven && shotnum % 7 == 0))
            MakeCritical(fireball);
        else
            fireball.isCritical = false;
        
        if (abilm.third && shotnum % 3 == 0) fireball.damage += 0.3f;
        fireball.damage *= dmg_coeff;
        if (abilm.penetrate) {
            fireball.penetrate = true;
        }
        fireball.psychosink = abilm.psychosink;
        fireball.beingstronger = abilm.beingstronger;
        fireball.udo = abilm.udo;
        fireball.freezing = abilm.freezing;
        fireball.damage += fix_damage;
    }

    public void GetWing(int num) {
        for(int i = 0; i < num; i++) {
            var w = Instantiate(wing_prefab, wing_transform);
            wings.Add(w.GetComponent<Wing>());
        }
    }
}
