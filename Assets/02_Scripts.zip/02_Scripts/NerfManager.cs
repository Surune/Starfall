using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class NerfManager : MonoBehaviour {
    public int nerfLevel;
    public int highestLevel;
    public GameObject nerftext;
    public Transform content;
    public bool hardmode;

    [HideInInspector]
    public static string[] textList = {
        "최대체력 80으로 시작", "레벨업에 필요한 경험치 +5", "등장하는 적 수 -1", "별 이동 속도 +10%", "치명타 대미지 -10%",
        "치명타 확률 -10%", "대미지 계수 -5%", "연사 간격 +5%", "고정 피해 -0.05", "별이 죽을 때 메테오를 생성함",
        "메테오 속도 +25%", "적 체력 +2", "치명타 확률 -5%, 대미지 -5%", "대미지 -0.05", "별이 무작위로 나타남",
        "적 크기 감소", "연사 간격 +0.05초", "아이템이 나타날 확률 -2%", "적이 받는 피해 -5%" , "피해를 받으면 즉사"
    };

    public static string[] hardmode_text = {
        "메테오가 빨라집니다", "별이 빨라집니다", "별 체력이 증가합니다", "별이 적게 나타납니다"
    };

    void Start() {
        nerfLevel = PlayerPrefs.GetInt("currentLevel", 0);
        highestLevel = PlayerPrefs.GetInt("highestLevel", 0);
        hardmode = System.Convert.ToBoolean(PlayerPrefs.GetInt("hardMode", 0));
        /*
        for (int i = 0; i < nerfLevel; i++) {
            GameObject obj = Instantiate(nerftext, content);
            obj.transform.localPosition = new Vector3(0f, -i * 80, 0f); // 위치 설정
            obj.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = textList[i];
            obj.GetComponent<Tween>().tween();
        }
        */
        Invoke("SetSupernova", 0f);
        if(hardmode) {
            GameManager.Instance.coin_coeff += 0.5f;
            ChoiceButton.hardmode = true;
            StartCoroutine(SetHardmode());
        }
        else {
            ChoiceButton.hardmode = false;
        }
    }

    private System.Collections.IEnumerator SetHardmode() {
        GameObject choice = GameObject.Find("Choice(Clone)");
        if (choice != null) {
            yield return new WaitUntil(() => choice == null);
        }
        
        if (hardmode) {
            int ran = Random.Range(0, hardmode_text.Length);
            GameObject obj = Instantiate(nerftext, content);
            switch(ran) {
                case 0:
                    GameManager.Instance.spawner.meteor_coeff *= 1.25f;
                    break;
                case 1:
                    GameManager.Instance.spawner.speed_coeff += 0.2f;
                    break;
                case 2:
                    GameManager.Instance.spawner.addHP += 2f;
                    break;
                case 3:
                    GameManager.Instance.timer.addition -= 1;
                    break;
            }
            obj.transform.GetComponent<TextMeshProUGUI>().text = "- 별의 시련 -\n\n" + hardmode_text[ran];
            obj.GetComponent<Tween>().tween();
        }
    }

    private void SetSupernova() {
        for (int i = 1; i <= nerfLevel; i++) {
            switch (i) {
                case 20:
                    GameManager.Instance.hp.lethal = true;
                    break;
                case 19:
                    GameManager.Instance.spawner.dmg_coeff -= 0.05f;
                    break;
                case 18:
                    Enemy.item_prob = 1f;
                    break;
                case 17:
                    GameManager.Instance.player.ChangeSkillCool(GameManager.Instance.player.skillcool_max + 0.05f);
                    break;
                case 16:
                    GameManager.Instance.spawner.spawns_small = true;
                    break;
                case 15:
                    GameManager.Instance.spawner.spawns_random = true;
                    break;
                case 14:
                    GameManager.Instance.plm.damage -= 0.05f;
                    break;
                case 13:
                    GameManager.Instance.plm.crit_dmg -= 0.05f;
                    GameManager.Instance.plm.crit_prob -= 0.05f;
                    break;
                case 12:
                    GameManager.Instance.spawner.addHP += 2;
                    break;
                case 11:
                    GameManager.Instance.spawner.meteor_coeff *= 1.25f;
                    break;
                case 10:
                    GameManager.Instance.spawner.makes_meteor = true;
                    break;
                case 9:
                    GameManager.Instance.plm.fix_damage -= 0.05f;
                    break;
                case 8:
                    GameManager.Instance.player.ChangeSkillCool(GameManager.Instance.player.skillcool_max * 1.05f);
                    break;
                case 7:
                    GameManager.Instance.plm.dmg_coeff = 0.95f;
                    break;
                case 6:
                    GameManager.Instance.plm.crit_prob -= 0.1f;
                    break;
                case 5:
                    GameManager.Instance.plm.crit_dmg -= 0.1f;
                    break;
                case 4:
                    GameManager.Instance.spawner.speed_coeff += 0.1f;
                    break;
                case 3:
                    GameManager.Instance.timer.addition -= 1;
                    break;
                case 2:
                    GameManager.Instance.exp.exp_max += 5;
                    break;
                case 1:
                    GameManager.Instance.hp.maxHP = 80f;
                    GameManager.Instance.hp.currentHP = 80f;
                    break;
                default:
                    break;
            }
        }
        GameManager.Instance.exp.SetText();
    }

    public void Cleared() {
        if(nerfLevel == highestLevel && highestLevel < textList.Length){
            PlayerPrefs.SetInt("highestLevel", highestLevel + 1);
        }
    }
}
