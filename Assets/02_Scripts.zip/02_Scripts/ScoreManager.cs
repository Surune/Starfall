using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ScoreManager : MonoBehaviour {
    public float score_total = 0;
    
    [SerializeField]
    private TextMeshProUGUI scoreText;
    
    [SerializeField]
    private AudioSource musicPlayer;

    private void SetScoreText() {
        scoreText.text = "" + (int)score_total;
    }

    public void GetScore(int num) {
        score_total += num;
        PlayerPrefs.SetInt("NowScore", Mathf.RoundToInt(score_total));

        SetScoreText();
    }
}
