using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using static GameState;

public class Pause : MonoBehaviour {
    [SerializeField]
    private GameObject text;
    [SerializeField]
    private GameObject content;
    [SerializeField]
    private GameObject ability;
    public Camera myCamera;

    public void PauseOnClick() {
        if (GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            GameStateManager.Instance.SetState(GameState.Paused);
            text.SetActive(true);
            myCamera.cullingMask = ~( (1 << 3) | (1 << 6) );
        }
        else if (GameStateManager.Instance.CurrentGameState == GameState.Paused) {
            GameStateManager.Instance.SetState(GameState.Gameplay);
            text.SetActive(false);
            myCamera.cullingMask = -1;
        }
    }
}
