using UnityEngine;
using System.Threading.Tasks; // [변경] async 기능을 이용하기 위해서는 해당 namepsace가 필요합니다.
using BackEnd;
using System;
using System.Collections.Generic;
using static GameDataItem;

public class BackendManager : MonoBehaviour {
    void Start() {
        var bro = Backend.Initialize(true); // 뒤끝 초기화

        // 뒤끝 초기화에 대한 응답값
        if (bro.IsSuccess()) {
            Debug.Log("초기화 성공 : " + bro); // 성공일 경우 statusCode 204 Success
        } else {
            Debug.LogError("초기화 실패 : " + bro); // 실패일 경우 statusCode 400대 에러 발생 
        }

        /*
        BackendReturnObject bro2 = Backend.BMember.GuestLogin( "게스트 로그인으로 로그인함" );
        if(bro2.IsSuccess()) {
            Debug.Log("게스트 로그인에 성공했습니다");
        }
        */
    }

    public void UploadGameData(bool cleared) {
        try {
            //Start();
            // 능력들과 클리어 여부, 게임 버전을 서버에 업로드
            GameDataItem gameData = new GameDataItem();
            gameData.gameVersion = Application.version;
            gameData.isCleared = cleared;
            gameData.abilities = GameManager.Instance.ab_nums;

            Param param = gameData.ToParam();

            var bro = Backend.GameData.Insert("gameData", param);

            if (bro.IsSuccess()) {
                string playerInfoIndate = bro.GetInDate();
                //Debug.Log("내 playerInfo의 indate : " + playerInfoIndate);
            }
            else {
                Debug.LogError("게임 정보 삽입 실패 : " + bro.ToString());
            }
        }
        catch (Exception e) {
            Debug.LogError("Processing failed : " + e);
        }
    }
}