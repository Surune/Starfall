using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour {
    public Toggle soundToggle; // 배경음 음소거 토글 버튼

    private AudioSource[] audioSources;

    // Singleton pattern 적용
    private static SoundManager instance = null;

    public static SoundManager Instance {
        get { return instance; }
    }

    private void Awake() {
        // SoundManager 객체가 이미 존재하는지 확인
        if (instance != null && instance != this) {
            // 이미 존재하는 객체이므로 현재 객체는 파괴
            Destroy(gameObject);
            return;
        }

        // 새로운 객체인 경우 instance에 할당
        instance = this;

        // Scene 전환 시 파괴되지 않도록 함
        DontDestroyOnLoad(gameObject);
    }

    void Start() {
        // 현재 Scene에서 Toggle 버튼을 찾음
        FindToggle();

        audioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in audioSources) {
            audioSource.mute = PlayerPrefs.GetInt("soundMuted") == 1;
        }

        SceneManager.activeSceneChanged += OnSceneChanged;
    }

    private void OnDestroy() {
        SceneManager.activeSceneChanged -= OnSceneChanged;
    }

    private void OnSceneChanged(Scene currentScene, Scene nextScene) {
        // Scene이 전환될 때마다 Toggle 버튼을 찾음
        FindToggle();
        audioSources = FindObjectsOfType<AudioSource>();
        foreach (AudioSource audioSource in audioSources) {
            audioSource.mute = PlayerPrefs.GetInt("soundMuted") == 1;
        }
    }

    private void FindToggle() {
        // 현재 Scene에서 BGM Toggle 버튼을 찾음
        var obj = GameObject.Find("SoundToggle");
        if (obj != null) {
            soundToggle = obj.GetComponent<Toggle>();
            soundToggle.isOn = PlayerPrefs.GetInt("soundMuted") == 1;
            soundToggle.onValueChanged.AddListener(SetMute);
        }
    }

    // 음소거 설정
    public void SetMute(bool _isMuted) {
        foreach (AudioSource audioSource in audioSources) {
            audioSource.mute = _isMuted;
        }
        PlayerPrefs.SetInt("soundMuted", _isMuted ? 1 : 0);
    }
}
