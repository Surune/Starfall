﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using static GameState;

public class HPManager : MonoBehaviour {
    private Slider healthbar;
    public float currentHP;
    public float maxHP;
    private AudioSource musicPlayer;
    public GameObject gameOverDisplay;
    public AudioClip sfx_hit;
    public AudioClip sfx_barrier;
    [SerializeField]
    private TextMeshProUGUI hp_text;
    [SerializeField]
    private TextMeshProUGUI barrier_text;
    public int barrier = 0;
    [HideInInspector]
    public bool meatshield = false;
    [HideInInspector]
    public bool porcupine = false;
    [HideInInspector]
    public bool blunt = false;
    [HideInInspector]
    public bool our_l = false;
    [HideInInspector]
    public bool our_r = false;
    [HideInInspector]
    public bool lethal = false;
    [HideInInspector]
    public bool carving = false;
    [HideInInspector]
    public bool virgo = false;
    [HideInInspector]
    public bool berserk = false;
    [HideInInspector]
    public bool capricon = false;
    private Player _pl;

    // Use this for initialization
    void Start () {
        healthbar = GetComponent<Slider>();
        maxHP = 100f;
        currentHP = maxHP;
        barrier = 0;
        healthbar.value = currentHP;
        musicPlayer = GameObject.Find("Player").GetComponent<AudioSource>();
        _pl = GameObject.Find("Player").GetComponent<Player>();
        PlayerPrefs.SetFloat("nowdeck", 0f);
        barrier_text = _pl.barrier.GetComponent<TextMeshProUGUI>();
    }

    public void SetHealthBar() {
        healthbar.maxValue = maxHP;
        healthbar.value = currentHP;
        hp_text.text = currentHP + " / " + maxHP;
    }

    public void GetBarrier(int num) {
        barrier += num;
        _pl.barrier.SetActive(true);
        barrier_text.text = "" + barrier;
    }

    public bool ChangeHP(int delta){
        if (currentHP + delta >= 0) {
            currentHP += delta;
            SetHealthBar();
            return true;
        }
        else {
            currentHP = 1;
            SetHealthBar();
            return false;
        }
    }

    public void GetDamage(int delta) {
        if (delta < 0) {
            if (barrier > 0) {
                barrier -= 1;
                barrier_text.text = "" + barrier;
                if (barrier == 0) {
                    _pl.barrier.SetActive(false);
                }
                if (meatshield) ChangeHP(+10);
                if (blunt) GameManager.Instance.plm.damage += 0.2f;
                if (our_l) GameManager.Instance.plm.crit_prob += 0.1f;
                if (our_r) GameManager.Instance.plm.crit_dmg += 0.1f;
                if (carving) _pl.ChangeSkillCool(_pl.skillcool_max * 0.9f);
                if (capricon) GameManager.Instance.spawner.SpawnItem();
                delta = 0;
                musicPlayer.PlayOneShot(sfx_barrier);
            }
            else {
                if (berserk) GameManager.Instance.plm.damage += 0.05f;
                if (virgo) delta = delta > 10 ? 10 : delta;
                if (porcupine) GameManager.Instance.plm.DamageAllEnemy(-delta);
                musicPlayer.PlayOneShot(sfx_hit);
                if (lethal) currentHP = 0;
            }
        }
        currentHP += delta;
        if (currentHP >= maxHP) currentHP = maxHP;

        if (currentHP <= 0) {
            GameManager.Instance.GameOver(0);
            GameStateManager.Instance.SetState(GameState.Paused);
            Instantiate(gameOverDisplay, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        SetHealthBar();
    }
}
