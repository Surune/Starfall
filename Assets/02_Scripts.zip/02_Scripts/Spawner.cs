﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class Spawner : MonoBehaviour {
    public bool spawn_enabled = true;
    [SerializeField]
    private float boundary;
    [SerializeField]
    private GameObject EnemyPrefab;
    [SerializeField]
    private GameObject BossPrefab;
    [SerializeField]
    private int EnemyTypeNum;
    public TextMeshProUGUI resourceText;
    public float enemydelay;
    public int enemynum = 1;
    public float speed_coeff = 1f;
    public GameObject EnemyList;
    public GameObject MeteorList;
    private Timer timer;
    private float max_x, max_y;
    private float mindelay = 0.005f;
    private static float[] speed_list = {1.25f, 2f, 7f, 1.25f, 1.25f, 1.5f, 2f};
    public float dmg_coeff = 1f;
    public float meteor_coeff = 1f;
    [HideInInspector]
    public bool disabled = false;
    [HideInInspector]
    public bool makes_meteor = false;
    [HideInInspector]
    public bool spawns_small = false;
    [HideInInspector]
    public bool spawns_random = false;
    public float addHP = 0f;
    public AudioSource _musicplayer;
    public AudioClip sfx_meteor;

    public Color[] color_list;

    void Start() {
        InvokeRepeating("SpawnEnemy", 0, enemydelay);
        EnemyList = GameObject.Find("Enemies");
        timer = GameObject.Find("Timer").GetComponent<Timer>();
        max_x = EnemyList.GetComponent<RectTransform>().rect.width/2 * boundary;
        max_y = EnemyList.GetComponent<RectTransform>().rect.height/2;

        speed_coeff = 1f;
        
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
    }
    
    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    public void ChangeSpawnDelay(float newcooltime) {
        if (newcooltime < mindelay) newcooltime = mindelay;
        enemydelay = newcooltime;
        CancelInvoke("SpawnEnemy");
        InvokeRepeating("SpawnEnemy", 0, enemydelay);
    }

    public GameObject SpawnMeteor(int type) {
        if (!disabled) {
            _musicplayer.PlayOneShot(sfx_meteor);
            GameObject meteor = GameManager.Instance.pool.Get(4);
            meteor.transform.position = new Vector3(GameManager.Instance.player.transform.position.x, max_y, 0f);
            meteor.GetComponent<Meteor>().speed *= meteor_coeff;
            return meteor;
        }
        else
            return null;
    }

    public GameObject SpawnFinalBoss() {
        foreach(Transform t in GameManager.GetAllChilds(EnemyList.transform)){
            t.gameObject.SetActive(false);
        }
        GameObject enemy = Instantiate(BossPrefab, new Vector3(0f, max_y, 0f), Quaternion.identity);
        enemy.transform.SetParent(EnemyList.transform);
        GameManager.Instance.active_enemy_num += 1;
        return enemy;
    }

    public Enemy SpawnEnemyWithType(int type, Vector3 pos) {
        GameObject enemy = GameManager.Instance.pool.Get(0);
        enemy.transform.GetChild(0).GetComponent<SpriteRenderer>().color = color_list[type];
        enemy.transform.position = pos;
        if(!spawns_small)
            enemy.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        else
            enemy.transform.localScale = new Vector3(1f, 1f, 1f);
        Enemy e = enemy.GetComponent<Enemy>();
        e.maxspeed = speed_list[type] * speed_coeff;
        e.SetType(type);
        return e;
    }

    public void SpawnItem() {
        GameObject item = GameManager.Instance.pool.Get(7);
        item.transform.position = new Vector3(Random.Range(-max_x, max_x), max_y, 0f);
        item.GetComponent<DropItem>().SetType((int)Random.Range(0, 4));
    }

    private void SpawnEnemy() {
        if (GameStateManager.Instance.CurrentGameState == GameState.Gameplay && !timer.waiting && enemynum > 0) {
            int ran = 0;
            if (!spawns_random) {
                ran = Random.Range(0, timer.wavenum < EnemyTypeNum ? timer.wavenum : EnemyTypeNum);
            }
            else {
                ran = Random.Range(0, EnemyTypeNum);
            }
            
            Enemy enemy = SpawnEnemyWithType(ran, new Vector3(Random.Range(-max_x, max_x), max_y, 0f));
            if (timer.roundnum % timer.bossperwave != 0) {
                enemy.isBoss = false;
                enemy.exp_amount = 1;
            }
            else {
                enemy.MakeBoss();
                enemy.exp_amount = timer.wavenum + 1;
            }
            enemy.makes_meteor = makes_meteor;
            enemy.maxHP = enemy.maxHP + addHP > 1 ? enemy.maxHP + addHP : 1f;
            enemy.currentHP = enemy.maxHP;
            enemy.SetHPText();
            enemynum -= 1;
            GameManager.Instance.active_enemy_num += 1;
        }
    }

    private void OnGameStateChanged(GameState newGameState) {
        spawn_enabled = (newGameState == GameState.Gameplay);
    }
}