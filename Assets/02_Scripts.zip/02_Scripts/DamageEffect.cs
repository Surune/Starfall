﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DamageEffect : MonoBehaviour {
    public float delay;
    public TextMeshProUGUI resourceText;
    [HideInInspector]
    public float acc_time;

    void Update () {
        if (gameObject.activeSelf && GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            acc_time += Time.deltaTime;
            if(acc_time > delay) {
                gameObject.SetActive(false);
            }
            else {
                var orig = resourceText.color;
                resourceText.color = new Color(orig.r, orig.g, orig.b, 1 - (acc_time / delay));
            }
        }
    }
}
