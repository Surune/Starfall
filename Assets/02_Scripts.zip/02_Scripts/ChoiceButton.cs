﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using static GameState;
using static CSVReader;

public class ChoiceButton : MonoBehaviour {
    [SerializeField]
    private GameObject canvas;
    [SerializeField]
    private GameObject refreshButton;
    [SerializeField]
    private Transform[] buttons;
    [SerializeField]
    private int[] btnnums;
    [SerializeField]
    private List<int> selected_nums;
    [SerializeField]
    private AudioClip sfx_refresh;
    [SerializeField]
    private AudioClip sfx_select;
    [SerializeField]
    private static AbilityManager abilm;
    private static PlayerManager plm;
    [SerializeField]
    private TextMeshProUGUI info;
    public static bool hardmode = false;

    void Start () {
        selected_nums = GameManager.Instance.ab_nums;
        if(abilm == null)   abilm = GameManager.Instance.abilm;
        if(plm == null)     plm = GameManager.Instance.plm;
        
        btnnums = new int[buttons.Length];
        
        GameManager.Instance.active_choice_num += 1;
        GameStateManager.Instance.SetState(GameState.Paused);
        
        SetRefreshText();
        TweenButtons();
        SetChoicenum();
        
        if (!hardmode)
            buttons[3].gameObject.SetActive(false);

        info.text = "현재까지 처치한 적 " + GameManager.Instance.player.killnum
                    + "\n공격력 " + plm.damage + " / 공격력 계수 " + plm.dmg_coeff
                    + "\n연사 간격 " + GameManager.Instance.player.skillcool_max
                    + "\n치명타 확률 " + plm.crit_prob*100 + "% / 치명타 대미지 " + plm.crit_dmg
                    + "\n즉사탄 확률 " + plm.fatal_prob*100 + "% / 고정 피해 " + plm.fix_damage;
    }

    private void SetChoicenum() {
        for (int i = 0; i < buttons.Length; i++) {
            while (true) {
                btnnums[i] = Random.Range(0, abilm.ab_sprites.Length);
                bool isSame = false;
                if (selected_nums.Contains(btnnums[i])) isSame = true;

                for (int j = 0; j < i; j++) {
                    if (btnnums[j] == btnnums[i]) {
                        isSame = true;
                        break;
                    }
                }
                if (!isSame) break;
            }

            int rannum = btnnums[i];
            buttons[i].GetChild(0).gameObject.GetComponent<Image>().sprite = abilm.ab_sprites[rannum];
            SetSynergyIcon(buttons[i], rannum);
            buttons[i].GetChild(3).gameObject.GetComponent<TextMeshProUGUI>().text = abilm.ab_list[rannum]["NAME"].ToString();
            buttons[i].GetChild(4).gameObject.GetComponent<TextMeshProUGUI>().text = abilm.ab_list[rannum]["DESCRIPTION"].ToString();
        }
    }

    private void SetSynergyIcon(Transform button, int num) {
        int s1 = int.Parse(abilm.ab_list[num]["SYNERGY1"].ToString());
        if(s1 == 0) {
            button.GetChild(1).gameObject.SetActive(false);
        }
        else {
            button.GetChild(1).gameObject.SetActive(true);
            button.GetChild(1).GetChild(0).gameObject.GetComponent<Image>().sprite = abilm.Synergy_sprite(s1);
            button.GetChild(1).gameObject.GetComponent<Image>().color = abilm.Synergy_color(s1);
        }
        
        int s2 = int.Parse(abilm.ab_list[num]["SYNERGY2"].ToString());
        if(s2 == 0) {
            button.GetChild(2).gameObject.SetActive(false);
        }
        else {
            button.GetChild(2).gameObject.SetActive(true);
            button.GetChild(2).GetChild(0).gameObject.GetComponent<Image>().sprite = abilm.Synergy_sprite(s2);
            button.GetChild(2).gameObject.GetComponent<Image>().color = abilm.Synergy_color(s2);
        }
    }
    
    public void Clicked(int i) {
        abilm.Choiced(btnnums[i]);
        GameManager.Instance.active_choice_num--;
        GameManager.Instance.eff.GetComponent<AudioSource>().PlayOneShot(sfx_select);
        GameManager.Instance.exp.SetText();
        if (GameManager.Instance.active_choice_num == 0) {
            GameStateManager.Instance.SetState(GameState.Gameplay);
        }
        Destroy(canvas);
    }

    private void TweenButtons() {
        foreach(var t in buttons) {
            t.gameObject.GetComponent<Tween>().tween();
        }
    }

    private void SetRefreshText() {
        refreshButton.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "새로고침 (" + plm.refresh + "회 남음)";
        if(plm.refresh <= 0) {
            refreshButton.GetComponent<Button>().interactable = false;
        }
    }

    public void Refresh() {
        if(plm.refresh > 0) {
            plm.refresh -= 1;
            GameManager.Instance.eff.GetComponent<AudioSource>().PlayOneShot(sfx_refresh);
            SetRefreshText();
            TweenButtons();
            SetChoicenum();
        }
    }
}
