using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HowToPlay : MonoBehaviour {
    public Image showing_image;
    public Sprite[] images;
    private int img_num = 0;

    // Start is called before the first frame update
    public void LeftClicked() { 
        if(img_num > 0) {
            showing_image.sprite = images[--img_num];
        }
    }

    // Update is called once per frame
    public void RightClicked() {
        if(img_num < images.Length-1) {
            showing_image.sprite = images[++img_num];
        }
    }
}
