using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {
    public static GameManager Instance;
    public EffectManager eff;
    public PoolManager pool;
    public PlayerManager plm;
    public AbilityManager abilm;
    public NerfManager nerf;
    public Player player;
    public Timer timer;
    public ExpManager exp;
    public ScoreManager scorer;
    public BackendManager backend;
    public Spawner spawner;
    public HPManager hp;
    public Transform enemylist;
    public Transform fireballlist;
    [HideInInspector]
    public int active_choice_num = 0;
    [HideInInspector]
    public int active_enemy_num = 0;
    [HideInInspector]
    public List<int> ab_nums = new List<int>();
    public float coin_coeff = 1f;

    void Start() {
        // 업그레이드 적용
        // 모듈 1 : 공격력 +0.02
        plm.damage += 0.02f * PlayerPrefs.GetInt("module_1");
        // 모듈 2 : 치명타 확률 +0.5%
        plm.crit_prob = 0.005f * PlayerPrefs.GetInt("module_2");
        // 모듈 3 : 치명타 대미지 +0.5%
        plm.crit_dmg += 0.005f * PlayerPrefs.GetInt("module_3");
        // 모듈 4 : 새로고침 횟수 추가
        plm.refresh += PlayerPrefs.GetInt("module_4");
        // 모듈 6 : 코인 획득량 + 1%
        coin_coeff += 0.01f * PlayerPrefs.GetInt("module_6");
        // 모듈 7 : 적 체력 -0.05
        spawner.addHP -= PlayerPrefs.GetInt("module_7") * 0.05f;
        // 모듈 8 : 적 속도 -0.5%
        spawner.speed_coeff -= PlayerPrefs.GetInt("module_8", 0) * 0.005f ;
    }

    public static Transform FindClosestTransform(List<Transform> t_list, Vector3 pos) {
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        foreach (Transform t in t_list) {
            float dist = Vector3.Distance(t.position, pos);
            if (dist < minDist) {
                tMin = t;
                minDist = dist;
            }
        }
        return tMin;
    }

    public static List<Transform> GetAllChilds(Transform _t) {
        List<Transform> ts = new List<Transform>();
        foreach (Transform t in _t) {
            if(t.gameObject.activeSelf == true) {
                ts.Add(t);
            }
        }
        return ts;
    }

    public void GameOver(int coin) {
        GetComponent<AudioSource>().Pause();
        GetCoin(0);
        backend.UploadGameData(false);
    }

    public void GameClear(int coin) {
        GetComponent<AudioSource>().Pause();
        nerf.Cleared();
        GetCoin(coin);
        backend.UploadGameData(true);
    }

    public void GetCoin(int bonus) {
        int nowscore = (int)scorer.score_total;
        
        if (bonus != 0) {
            coin_coeff += 0.05f * nerf.nerfLevel;
            nowscore = Mathf.CeilToInt(nowscore * (1 + 0.05f * nerf.nerfLevel));
        }
        int coins = Mathf.CeilToInt((exp.coins + bonus) * coin_coeff);
        if (nowscore > PlayerPrefs.GetInt("HighScore")) PlayerPrefs.SetInt("HighScore", nowscore);
        PlayerPrefs.SetInt("NowScore", nowscore);
        PlayerPrefs.SetInt("Coin", coins);
        int totalcoin = PlayerPrefs.GetInt("TotalCoin") + coins;
        PlayerPrefs.SetInt("TotalCoin", totalcoin);
        PlayerPrefs.Save();
    }
    
    private void Awake() {
        Instance = this;
    }
}