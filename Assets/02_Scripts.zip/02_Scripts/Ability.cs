using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ability : MonoBehaviour {
    public Image img_Skill;
    private static GameObject player;
    private static GameObject enemyList;
    private static PlayerManager plm;

    public float skillcool_max = 20f;
    private float skillcool_now = 0f;
    public int ability_num = 0;
    public int ability_type = 1;
    private bool shoot_enabled;

    void Start() {
        if (player == null)     player = GameObject.Find("Player");
        if (enemyList == null)  enemyList = GameObject.Find("Enemies");
        if (plm == null)        plm = GameManager.Instance.plm;
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
    }

    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    void Update() {
        if (ability_type != 0 && GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            skillcool_now += Time.deltaTime;
            if (skillcool_now >= skillcool_max) 
                Activate();
            img_Skill.fillAmount = skillcool_now / skillcool_max;
        }
    }

    public void Activate() {
        skillcool_now = 0;
        if (ability_type == 1) {
            GameObject fireball;
            switch (ability_num) {
                case 2:
                    fireball = GameManager.Instance.pool.Get(1);
                    fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                    fireball.transform.position = player.transform.position;
                    fireball.GetComponent<Fireball>().damage = 1f;
                    break;
                case 3:
                    fireball = GameManager.Instance.pool.Get(1);
                    fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                    fireball.transform.position = player.transform.position;
                    plm.SetFireInfo(fireball.GetComponent<Fireball>());
                    break;
                case 17:
                    plm.DamageAllEnemy(plm.damage * plm.dmg_coeff + plm.fix_damage);
                    break;
                case 21:
                    fireball = GameManager.Instance.pool.Get(1);
                    fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                    fireball.transform.position = player.transform.position;
                    plm.SetFireInfo(fireball.GetComponent<Fireball>());
                    fireball.GetComponent<Fireball>().isFatal = true;
                    break;
                case 43:
                    plm.fix_damage += 0.05f;
                    break;
                case 45:
                    GameManager.Instance.hp.ChangeHP(+5);
                    break;
                case 47:
                    for (int i = 0; i < 6; i++) {
                        fireball = GameManager.Instance.pool.Get(1);
                        fireball.transform.position = player.transform.position;
                        fireball.transform.rotation = Quaternion.Euler(0, 0, 5*i-15);
                        fireball.GetComponent<Fireball>().damage = 6f;
                    }
                    break;
                case 63:
                    GameManager.Instance.hp.GetBarrier(1);
                    break;
                case 66:
                    plm.crit_prob += 0.025f;
                    break;
                case 70:
                    plm.crit_dmg += 0.025f;
                    break;
                case 77:
                    for (int i = 0; i < 3; i++) {
                        fireball = GameManager.Instance.pool.Get(1);
                        fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                        fireball.transform.position = player.transform.position;
                        fireball.GetComponent<Fireball>().damage = 1f;
                        fireball.GetComponent<Fireball>().udo = true;
                    }
                    break;
                case 79:
                    fireball = GameManager.Instance.pool.Get(1);
                    fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
                    fireball.transform.position = player.transform.position;
                    fireball.GetComponent<Fireball>().damage = 3f;
                    fireball.GetComponent<Fireball>().penetrate = true;
                    break;
                case 80:
                    player.GetComponent<Player>().reloading = true;
                    Invoke("ReloadOff", 0.5f);
                    break;
                case 84:
                    GameManager.Instance.plm.damage += 0.1f;
                    break;
                case 114:
                    player.GetComponent<Player>().ChangeSkillCool(player.GetComponent<Player>().skillcool_max - 0.01f);
                    break;
                case 135:
                    GameManager.Instance.spawner.SpawnItem();
                    break;
                default:
                    break;
            }
        }
        else if (ability_type == 2) {
            GameObject area = GameManager.Instance.pool.Get(5);
            area.GetComponent<Area>().SetIcon(transform.GetChild(1).gameObject.GetComponent<Image>().sprite);
            switch (ability_num) {
                case 19:
                    area.transform.position = player.transform.position + new Vector3(0f, 2f, 0f);
                    area.GetComponent<Area>().duration = 1.5f;
                    area.GetComponent<Area>().SetProperty(isFixed : true);
                    break;
                case 24:
                    area.transform.position = player.transform.position + new Vector3(0f, 7f, 0f);
                    area.GetComponent<Area>().duration = 1f;
                    area.GetComponent<Area>().SetProperty(isDamage : true);
                    break;
                case 55:
                    area.transform.position = player.transform.position + new Vector3(0f, 6f, 0f);
                    area.GetComponent<Area>().duration = 1f;
                    area.GetComponent<Area>().SetProperty(isSlow : true);
                    break;
                case 91:
                    area.transform.position = player.transform.position + new Vector3(0f, 4f, 0f);
                    area.GetComponent<Area>().duration = 1f;
                    area.GetComponent<Area>().SetProperty(isSwarm : true);
                    break;
                case 96:
                    area.transform.position = player.transform.position + new Vector3(0f, 5f, 0f);
                    area.GetComponent<Area>().duration = 1f;
                    area.GetComponent<Area>().SetProperty(isUnrelenting : true);
                    break;
                case 98:
                    area.transform.position = player.transform.position + new Vector3(0f, 3f, 0f);
                    area.GetComponent<Area>().duration = 1.5f;
                    area.GetComponent<Area>().SetProperty(isCrit : true);
                    break;
                default:
                    break;
            }
        }
    }

    private void ReloadOff() {
        player.GetComponent<Player>().reloading = false;
    }

    private void OnGameStateChanged(GameState newGameState) {
        shoot_enabled = (newGameState == GameState.Gameplay);
    }
}
