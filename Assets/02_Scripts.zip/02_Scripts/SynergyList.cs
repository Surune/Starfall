using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SynergyList : MonoBehaviour {
    [SerializeField]
    private TextMeshProUGUI[] texts;
    [SerializeField]
    private string[] descriptions;
    [SerializeField]
    private TextMeshProUGUI desc;

    private void Start() {
        for(int i = 0; i < texts.Length; i++) {
            texts[i].text = GameManager.Instance.abilm.synergy[i+1].ToString() + "/" + GameManager.Instance.abilm.synergy_requirement[i];
        }
    }

    public void OnImageClick(int i) {
        desc.text = descriptions[i];
    }
}