using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameOver : MonoBehaviour {
    [SerializeField]
    private TextMeshProUGUI ScoreText;

    // Start is called before the first frame update
    void Start() {
        string text = "Now Score : " + PlayerPrefs.GetInt("NowScore");
        text += "\n\nHigh Score : " + PlayerPrefs.GetInt("HighScore");
        text += "\n\nCoins : " + PlayerPrefs.GetInt("TotalCoin") + " (+" + PlayerPrefs.GetInt("Coin") + ")";
        ScoreText.text = text;
    }
}