using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CharacterManager : MonoBehaviour {
    public TextMeshProUGUI coinText;
    private int currentPilot = 0;
    public Transform[] characs;

    public AudioSource musicPlayer;
    public AudioClip sfx_purchase;
    public AudioClip sfx_select;
    
    private Store store;
    private void Start() {
        currentPilot = PlayerPrefs.GetInt("currentPilot");
        for (int i = 0; i < characs.Length; i++){
            bool having = System.Convert.ToBoolean(PlayerPrefs.GetInt("pilot_" + (i+1)));
            if (having) {
                characs[i].GetChild(3).gameObject.SetActive(false);
                characs[i].GetChild(4).gameObject.SetActive(true);
            }
            else {
                characs[i].GetChild(3).gameObject.SetActive(true);
                characs[i].GetChild(4).gameObject.SetActive(false);
            }
        }
        SelectCharacter(currentPilot);
        store = FindObjectOfType<Store>();
    }

    public void PurchaseCharacter(int num) {
        int coins = PlayerPrefs.GetInt("TotalCoin", 0);
        if (coins >= 1500) {
            coins -= 1500;
            PlayerPrefs.SetInt("TotalCoin", coins);
            PlayerPrefs.SetInt("pilot_" + num, System.Convert.ToInt16(true));
            PlayerPrefs.Save();
            characs[num-1].GetChild(4).gameObject.SetActive(true);
            characs[num-1].GetChild(3).gameObject.SetActive(false);
            coinText.text = "Coins : " + coins;
            musicPlayer.PlayOneShot(sfx_purchase);
        }
    }

    public void SelectCharacter(int num) {
        currentPilot = num;
        PlayerPrefs.SetInt("currentPilot", num);
        PlayerPrefs.Save();
        for (int i=0; i<characs.Length; i++){
            if(i == num-1) {
                characs[i].GetChild(4).gameObject.GetComponent<Button>().interactable = false;
            }
            else {
                characs[i].GetChild(4).gameObject.GetComponent<Button>().interactable = true;
            }
        }
        musicPlayer.PlayOneShot(sfx_select);
    }
}
