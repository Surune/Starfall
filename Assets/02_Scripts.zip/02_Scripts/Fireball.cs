using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static GameState;

public class Fireball : MonoBehaviour {
    private static Player _player;
    private Vector3 worldpos;
    public float speed = 20f;
    public float damage = 1f;
    public static float fatal_damage = 2f;
    public bool udo = false;
    public bool isCritical = false;
    public bool penetrate = false;
    public bool isFatal = false;
    public bool psychosink = false;
    public bool beingstronger = false;
    public bool burst = false;
    public bool freezing = false;

    private bool game_playing = true;

    void Start() {
        if(_player == null) _player = GameObject.Find("Player").GetComponent<Player>();
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
    }

    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    private void OnEnable() {
        udo = false;
        isCritical = false;
        penetrate = false;
        isFatal = false;
        psychosink = false;
        beingstronger = false;
        burst = false;
        freezing = false;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Enemy") {
            if (isFatal) {
                if (collision.gameObject.GetComponent<Enemy>().isBoss == false) {
                    collision.gameObject.GetComponent<Enemy>().GetDamage(damage, fatal : true);
                }
                else {
                    collision.gameObject.GetComponent<Enemy>().GetDamage(damage * fatal_damage, fatal : false);
                }
            }
            else if (psychosink) {
                GameManager.Instance.plm.DamageAllEnemy(damage);
            }
            else {
                collision.gameObject.GetComponent<Enemy>().GetDamage(damage, critical : isCritical);
            }
            
            if (isCritical && burst) collision.gameObject.GetComponent<Enemy>().GetDamage(GameManager.Instance.plm.damage, mute: true);
            if (freezing) collision.gameObject.GetComponent<Enemy>().slow_time = 2f;
            if (!penetrate) {
                gameObject.SetActive(false);
            }
            else penetrate = false;
        }
        else if (collision.transform.tag == "Boss") {
            if (isFatal) {
                damage *= fatal_damage;
            }
            collision.gameObject.GetComponent<Boss>().GetDamage(damage, isCritical);
            
            if (isCritical && burst) collision.gameObject.GetComponent<Boss>().GetDamage(GameManager.Instance.plm.damage, mute: true);
            if (freezing) collision.gameObject.GetComponent<Boss>().slow_time = 2f;
            gameObject.SetActive(false);
        }
    }

    void FixedUpdate () {
        worldpos = Camera.main.WorldToViewportPoint(this.transform.position);
        if (worldpos.x < 0f || worldpos.x > 1f || worldpos.y < 0f || worldpos.y > 1f) {
            gameObject.SetActive(false);
        }
        else if(game_playing) {
            if (udo) {
                Transform closest = GameManager.FindClosestTransform(GameManager.GetAllChilds(GameManager.Instance.enemylist), this.transform.position);
                if (closest != null && Vector2.Distance(this.transform.position, closest.position) < 1f)
                        transform.position = Vector3.Lerp(this.transform.position, closest.position, Time.smoothDeltaTime * speed);
                else 
                    transform.Translate(0, Time.smoothDeltaTime * speed, 0);
            }
            else transform.Translate(0, Time.smoothDeltaTime * speed, 0);

            if (beingstronger) damage += damage * Time.smoothDeltaTime;
        }
    }

    private void OnGameStateChanged(GameState newGameState) {
        game_playing = (newGameState == GameState.Gameplay);
    }
}
