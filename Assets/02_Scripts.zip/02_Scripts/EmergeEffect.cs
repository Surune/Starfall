using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmergeEffect : MonoBehaviour {
    private float time = 0;
    [SerializeField]
    private float delayTime = 3f;

    // Start is called before the first frame update
    void Start() {
        GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 0);
    }

    // Update is called once per frame
    void Update() {
        if (time < delayTime){
            GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, time/delayTime);
            time += time + Time.deltaTime;
        }
    }
}
