using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Openurl : MonoBehaviour {
    [SerializeField]
    string url;

    public void openlink() {
        Application.OpenURL(url);
    }
}
