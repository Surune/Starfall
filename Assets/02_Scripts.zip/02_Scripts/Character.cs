using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Character : MonoBehaviour {
    public Image img;
    public TextMeshProUGUI charname;
    public TextMeshProUGUI desc;
    public static int currentPilot;

    private string[] namelist = {"Stargazer", "Stardust", "Starking", "Starship", "Starpid", "Starlet"};
    private string[] desclist = {"시작시 능력 선택", "치명타 확률 +20%", "연사 간격 -20%", "보호막 +5", "대미지 +1", "필요 경험치 -5"};
    
    public Color[] colorlist;

    private void Start() {
        SetText();
    }

    public void SetText() {
        currentPilot = PlayerPrefs.GetInt("currentPilot", 1);
        charname.text = namelist[currentPilot-1];
        //desc.text = desclist[currentPilot-1];
        img.color = colorlist[currentPilot-1];
    }
}
