using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static GameState;

public class Meteor : MonoBehaviour {
    private static Vector3 move_direction = new Vector3(0, -1, 0);
    public float speed = 10f;
    private int damage;

    void Start() {
        damage = GameManager.Instance.timer.wavenum;
    }

    void OnEnable() {
        damage = GameManager.Instance.timer.wavenum;
    }

    // Update is called once per frame
    void Update() {
        if(gameObject.activeSelf && GameStateManager.Instance.CurrentGameState == GameState.Gameplay) {
            transform.position += move_direction * speed * Time.deltaTime;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Player") {
            GameManager.Instance.hp.GetDamage(-damage);
            gameObject.SetActive(false);
        }
    }
}