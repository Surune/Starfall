using BackEnd;
using System;
using System.Collections.Generic;

public class GameDataItem
{
    public string gameVersion = Backend.UserNickName;
    public bool isCleared;
    public List<int> abilities = new List<int>();
    public DateTime lastUpdate;

    public GameDataItem()
    {
    }

    public Param ToParam()
    {
        Param param = new Param();

        param.Add("gameVersion", gameVersion);
        param.Add("isCleared", isCleared);
        param.Add("abilities", abilities);
        param.Add("lastUpdate", DateTime.UtcNow);

        return param;
    }
}