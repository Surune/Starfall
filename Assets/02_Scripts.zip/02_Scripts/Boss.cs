using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using static GameState;

public class Boss : MonoBehaviour {
    private static Player player;
    private static ScoreManager scorer;
    private static EffectManager eff_manager;
    private static AudioSource musicPlayer;
    public GameObject gameClearDisplay;
    [SerializeField]
    private TextMeshProUGUI resourceText;
    public bool isBoss = true;
    public float maxspeed = 1f;
    private float speed;
    public float slow_time = 0f;
    private float acc_dmg = 0f;
    public float coeff = 1f;    //damage coefficient
    private Vector3 move_direction = new Vector3(0, -1, 0);
    [SerializeField]
    private AudioClip sfx_hit;
    [SerializeField]
    private AudioClip sfx_critical;

    void Start () {
        if(player == null)
            player = GameObject.Find("Player").GetComponent<Player>();
        if(scorer == null)
            scorer = GameObject.Find("ScoreManager").GetComponent<ScoreManager>();
        if(eff_manager == null)
            eff_manager = GameObject.Find("Effects").GetComponent<EffectManager>();
        if(musicPlayer == null)
            musicPlayer = GameObject.Find("Effects").GetComponent<AudioSource>();
        GameStateManager.Instance.OnGameStateChanged += OnGameStateChanged;
        enabled = (GameStateManager.Instance.CurrentGameState == GameState.Gameplay);
        resourceText.text = "" + Mathf.CeilToInt(acc_dmg);
        speed = maxspeed;
    }

    void OnDestroy() {
        GameStateManager.Instance.OnGameStateChanged -= OnGameStateChanged;
    }

    public bool GetDamage(float dmg, bool critical = false, bool mute = false) {
        dmg *= coeff;
        acc_dmg += dmg;
        eff_manager.SetDamageEffect(transform.position, dmg, critical);
        if (critical && GameManager.Instance.abilm.psychosense){
            GameObject fireball = GameManager.Instance.pool.Get(1);
            fireball.transform.position = player.transform.position;
            fireball.transform.rotation = Quaternion.Euler(0, 0, 0);
            fireball.GetComponent<Fireball>().damage = 3f;
        }
        
        GameObject p = GameManager.Instance.pool.Get(3);
        p.transform.position = transform.position;
        
        resourceText.text = "" + Mathf.CeilToInt(acc_dmg);
        if (!mute) {
            if (!critical) musicPlayer.PlayOneShot(sfx_hit);
            else    musicPlayer.PlayOneShot(sfx_critical);
        }
        return false;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.transform.tag == "Area") {
            var collidedarea = collision.gameObject.GetComponent<Area>();
            if (collidedarea.slow) speed = maxspeed * 0.75f;
            if (collidedarea.damage) acc_dmg -= Time.deltaTime;
        }
        else if (collision.transform.tag == "Player") {
            gameObject.SetActive(false);
            GameManager.Instance.active_enemy_num -= 1;
            GameManager.Instance.GameClear(Mathf.CeilToInt(acc_dmg * 0.01f));
            GameStateManager.Instance.SetState(GameState.Paused);
            Instantiate(gameClearDisplay, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
    }
    
    private void OnTriggerStay2D(Collider2D collision) {
        if (collision.transform.tag == "Area") {
            var collidedarea = collision.gameObject.GetComponent<Area>();
            if (collidedarea.slow) speed = maxspeed * 0.75f;
            if (collidedarea.damage) acc_dmg -= Time.deltaTime;
        }
    }

    private void OnTriggerExit2D(Collider2D collision) {
        if (collision.transform.tag == "Area")
            speed = maxspeed;
    }

    void Update () {
        if (slow_time > 0f) {
            slow_time -= Time.deltaTime;
            speed = maxspeed * 0.75f;
            if (slow_time <= 0f) {
                slow_time = 0f;
                speed = maxspeed;
            }
        }
        transform.Translate(move_direction * speed * Time.deltaTime);
    }

    private void OnGameStateChanged(GameState newGameState) {
        enabled = (newGameState == GameState.Gameplay);
    }
}
